




>1
```
Generate 1000000 numbers to be sorted on 1 processors.
Each processor get 1000000 numbers.
Sort total time :0.380965 s
serial time :0.0152512 s
Parallel partition time:0.365714 s
Total sort numbers: 1000000,  and the data sorted from1 to 99999
```

>2
```shell
Generate 2000000 numbers to be sorted on 2 processors.
Each processor get 1000000 numbers.
Sort total time :0.40783 s
serial time :0.0387511 s
Parallel partition time:0.369079 s
Total sort numbers: 2000000,  and the data sorted from1 to 99999
```

>4
```shell
Generate 4000000 numbers to be sorted on 4 processors.
Each processor get 1000000 numbers.
Sort total time :0.470713 s
serial time :0.0881071 s
Parallel partition time:0.382606 s
Total sort numbers: 4000000,  and the data sorted from1 to 99999
```

>8
```shell
Generate 8000000 numbers to be sorted on 8 processors.
Each processor get 1000000 numbers.
Sort total time :0.688769 s
serial time :0.238497 s
Parallel partition time:0.450272 s
Total sort numbers: 8000000,  and the data sorted from1 to 99999
```
>12
```shell
Generate 12000000 numbers to be sorted on 12 processors.
Each processor get 1000000 numbers.
Sort total time :1.03565 s
serial time :0.623986 s
Parallel partition time:0.411668 s
Total sort numbers: 12000000,  and the data sorted from1 to 99999

```

>16
```shell
Generate 16000000 numbers to be sorted on 16 processors.
Each processor get 1000000 numbers.
Sort total time :1.40279 s
serial time :0.9814 s
Parallel partition time:0.421386 s
Total sort numbers: 16000000,  and the data sorted from1 to 99999


```
>20
```shell
Generate 20000000 numbers to be sorted on 20 processors.
Each processor get 1000000 numbers.
Sort total time :1.80809 s
serial time :1.37371 s
Parallel partition time:0.434381 s
Total sort numbers: 20000000,  and the data sorted from1 to 99999

```

>24
```shell
Generate 24000000 numbers to be sorted on 24 processors.
Each processor get 1000000 numbers.
Sort total time :2.20099 s
serial time :1.75284 s
Parallel partition time:0.448153 s
Total sort numbers: 24000000,  and the data sorted from1 to 99999

```
>28
```shell
Generate 28000000 numbers to be sorted on 28 processors.
Each processor get 1000000 numbers.
Sort total time :2.60113 s
serial time :2.13666 s
Parallel partition time:0.464474 s
Total sort numbers: 28000000,  and the data sorted from1 to 99999

```
>32
```shell
Generate 32000000 numbers to be sorted on 32 processors.
Each processor get 1000000 numbers.
Sort total time :3.30611 s
serial time :2.82997 s
Parallel partition time:0.476138 s
Total sort numbers: 32000000,  and the data sorted from1 to 99999


```