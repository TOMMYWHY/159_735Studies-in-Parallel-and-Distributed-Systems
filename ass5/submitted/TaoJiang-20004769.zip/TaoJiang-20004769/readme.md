nvcc -o nsphere_cuda nsphere_cuda.cu -std=c++11
