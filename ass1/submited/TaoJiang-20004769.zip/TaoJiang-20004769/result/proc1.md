
```shell
Total Processors: 1
Master Processor name:: compute-0-4.local
Master processor 0: in_circle amount 785401923; total is 1000000000
Master processor 0 work time spend time: 25.2021 s 
----------------------------
Master total time:  25.2022 s 
Communication time: 6.81877e-05s
The 785401923 of 1000000000 points falls into the circle 

***** PI is 3.14160769
#############################################


```