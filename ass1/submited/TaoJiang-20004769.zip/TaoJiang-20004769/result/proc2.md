```shell
Total Processors: 2
Master Processor name:: compute-0-4.local
send 1030549473 to slave 1
Slave processor 1  in_circle amount:  392696277 total is: 500000000
Slave processor 1 total spend time:: 12.586 s 

Master processor 0: in_circle amount 392705646; total is 500000000
Master processor 0 work time spend time: 12.6183 s 
----------------------------
Master total time:  12.6184 s 
Communication time: 9.13143e-05s
The 785401923 of 1000000000 points falls into the circle 

***** PI is 3.14160769
#############################################

```