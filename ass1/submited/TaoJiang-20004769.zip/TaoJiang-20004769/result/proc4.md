```shell
Total Processors: 4
Master Processor name:: compute-0-4.local
send 1030549473 to slave 1
send 797165516 to slave 2
send 2863095995 to slave 3
Slave processor 3  in_circle amount:  196349290 total is: 250000000
Slave processor 3 total spend time:: 6.30827 s 

Master processor 0: in_circle amount 196355700; total is 250000000
Master processor 0 work time spend time: 6.30917 s 
Slave processor 2  in_circle amount:  196349946 total is: 250000000
Slave processor 2 total spend time:: 6.31106 s 

Slave processor 1  in_circle amount:  196346987 total is: 250000000
Slave processor 1 total spend time:: 6.31528 s 

----------------------------
Master total time:  6.31523 s 
Communication time: 0.00606203s
The 785401923 of 1000000000 points falls into the circle 

***** PI is 3.14160769
#############################################

```