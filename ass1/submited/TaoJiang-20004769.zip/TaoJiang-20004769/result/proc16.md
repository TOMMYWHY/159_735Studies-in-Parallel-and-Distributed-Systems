```shell
[s20004769@mighty ass1]$ cat pi.stdout 
Total Processors: 16
Master Processor name:: compute-0-4.local
send 1030549473 to slave 1
send 797165516 to slave 2
send 2863095995 to slave 3
send 163339998 to slave 4
send 209336485 to slave 5
send 424841664 to slave 6
send 2809322015 to slave 7
send 3442696434 to slave 8
send 2555202473 to slave 9
send 671228148 to slave 10
send 1434441667 to slave 11
send 2515507782 to slave 12
send 1642573037 to slave 13
send 1732127080 to slave 14
send 1245609383 to slave 15
Slave processor 1  in_circle amount:  49085981 total is: 62500000
Slave processor 1 total spend time:: 1.57461 s 

Slave processor 5  in_circle amount:  49086255 total is: 62500000
Slave processor 5 total spend time:: 1.57458 s 

Slave processor 9  in_circle amount:  49088838 total is: 62500000
Slave processor 9 total spend time:: 1.57425 s 

Slave processor 14  in_circle amount:  49087930 total is: 62500000
Slave processor 14 total spend time:: 1.57422 s 

Slave processor 10  in_circle amount:  49085214 total is: 62500000
Slave processor 10 total spend time:: 1.57448 s 

Slave processor 12  in_circle amount:  49090044 total is: 62500000
Slave processor 12 total spend time:: 1.57468 s 

Slave processor 2  in_circle amount:  49089621 total is: 62500000
Slave processor 2 total spend time:: 1.57623 s 

Slave processor 6  in_circle amount:  49087181 total is: 62500000
Slave processor 6 total spend time:: 1.57643 s 

Slave processor 13  in_circle amount:  49085913 total is: 62500000
Slave processor 13 total spend time:: 1.57779 s 

Slave processor 7  in_circle amount:  49087447 total is: 62500000
Slave processor 7 total spend time:: 1.57863 s 

Slave processor 8  in_circle amount:  49088296 total is: 62500000
Slave processor 8 total spend time:: 1.57834 s 

Slave processor 3  in_circle amount:  49086770 total is: 62500000
Slave processor 3 total spend time:: 1.57898 s 

Slave processor 4  in_circle amount:  49086982 total is: 62500000
Slave processor 4 total spend time:: 1.57972 s 

Slave processor 15  in_circle amount:  49087985 total is: 62500000
Slave processor 15 total spend time:: 1.57931 s 

Slave processor 11  in_circle amount:  49087088 total is: 62500000
Slave processor 11 total spend time:: 1.58074 s 

Master processor 0: in_circle amount 49090378; total is 62500000
Master processor 0 work time spend time: 1.57974 s 
----------------------------
Master total time:  1.58399 s 
Communication time: 0.00424528s
The 785401923 of 1000000000 points falls into the circle 

***** PI is 3.14160769


```