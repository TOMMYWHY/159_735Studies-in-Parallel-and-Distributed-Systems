```shell

Total Processors: 8
Master Processor name:: compute-0-4.local
send 1030549473 to slave 1
send 797165516 to slave 2
send 2863095995 to slave 3
send 163339998 to slave 4
send 209336485 to slave 5
send 424841664 to slave 6
send 2809322015 to slave 7
Slave processor 2  in_circle amount:  98174835 total is: 125000000
Slave processor 2 total spend time:: 3.15193 s 

Slave processor 1  in_circle amount:  98174819 total is: 125000000
Slave processor 1 total spend time:: 3.15226 s 

Master processor 0: in_circle amount 98178674; total is 125000000
Master processor 0 work time spend time: 3.15437 s 
Slave processor 4  in_circle amount:  98177026 total is: 125000000
Slave processor 4 total spend time:: 3.15617 s 

Slave processor 6  in_circle amount:  98175111 total is: 125000000
Slave processor 6 total spend time:: 3.15822 s 

Slave processor 5  in_circle amount:  98172168 total is: 125000000
Slave processor 5 total spend time:: 3.16031 s 

Slave processor 7  in_circle amount:  98175432 total is: 125000000
Slave processor 7 total spend time:: 3.16283 s 

Slave processor 3  in_circle amount:  98173858 total is: 125000000
Slave processor 3 total spend time:: 3.16432 s 

----------------------------
Master total time:  3.16437 s 
Communication time: 0.010004s
The 785401923 of 1000000000 points falls into the circle 

***** PI is 3.14160769
#############################################

```