```shell
Total Processors: 32
Master Processor name:: compute-0-4.local
send 1030549473 to slave 1
send 797165516 to slave 2
send 2863095995 to slave 3
send 163339998 to slave 4
send 209336485 to slave 5
send 424841664 to slave 6
send 2809322015 to slave 7
send 3442696434 to slave 8
send 2555202473 to slave 9
send 671228148 to slave 10
send 1434441667 to slave 11
send 2515507782 to slave 12
send 1642573037 to slave 13
send 1732127080 to slave 14
send 1245609383 to slave 15
send 754638554 to slave 16
send 1027678321 to slave 17
send 1991483164 to slave 18
send 1588539339 to slave 19
send 2201109166 to slave 20
send 1871424053 to slave 21
send 730117648 to slave 22
send 440832559 to slave 23
send 4141488578 to slave 24
send 800558649 to slave 25
send 2935808580 to slave 26
send 4195453139 to slave 27
send 1215428630 to slave 28
send 2369212541 to slave 29
send 1317328824 to slave 30
send 941176759 to slave 31
Slave processor 15  in_circle amount:  24543662 total is: 31250000
Slave processor 15 total spend time:: 0.786378 s 

Slave processor 10  in_circle amount:  24541227 total is: 31250000
Slave processor 10 total spend time:: 0.786786 s 

Slave processor 9  in_circle amount:  24544046 total is: 31250000
Slave processor 9 total spend time:: 0.787122 s 

Slave processor 6  in_circle amount:  24543626 total is: 31250000
Slave processor 6 total spend time:: 0.788227 s 

Slave processor 8  in_circle amount:  24543881 total is: 31250000
Slave processor 8 total spend time:: 0.788721 s 

Slave processor 12  in_circle amount:  24543923 total is: 31250000
Slave processor 12 total spend time:: 0.78915 s 

Slave processor 13  in_circle amount:  24543098 total is: 31250000
Slave processor 13 total spend time:: 0.789258 s 

Slave processor 3  in_circle amount:  24543641 total is: 31250000
Slave processor 3 total spend time:: 0.789763 s 

Slave processor 4  in_circle amount:  24544149 total is: 31250000
Slave processor 4 total spend time:: 0.790407 s 

Slave processor 14  in_circle amount:  24542161 total is: 31250000
Slave processor 14 total spend time:: 0.790032 s 

Slave processor 2  in_circle amount:  24545867 total is: 31250000
Slave processor 2 total spend time:: 0.790697 s 

Slave processor 1  in_circle amount:  24542855 total is: 31250000
Slave processor 1 total spend time:: 0.790836 s 

Slave processor 5  in_circle amount:  24543033 total is: 31250000
Slave processor 5 total spend time:: 0.79099 s 

Slave processor 18  in_circle amount:  24543754 total is: 31250000
Slave processor 18 total spend time:: 0.791506 s 

Slave processor 16  in_circle amount:  24543723 total is: 31250000
Slave processor 16 total spend time:: 0.791811 s 

Slave processor 17  in_circle amount:  24543126 total is: 31250000
Slave processor 17 total spend time:: 0.791774 s 

Slave processor 11  in_circle amount:  24542741 total is: 31250000
Slave processor 11 total spend time:: 0.792337 s 

Slave processor 20  in_circle amount:  24542833 total is: 31250000
Slave processor 20 total spend time:: 0.792797 s 

Slave processor 21  in_circle amount:  24543222 total is: 31250000
Slave processor 21 total spend time:: 0.792678 s 

Slave processor 19  in_circle amount:  24543129 total is: 31250000
Slave processor 19 total spend time:: 0.792997 s 

Slave processor 7  in_circle amount:  24543164 total is: 31250000
Slave processor 7 total spend time:: 0.794072 s 

Slave processor 23  in_circle amount:  24544283 total is: 31250000
Slave processor 23 total spend time:: 0.794395 s 

Slave processor 28  in_circle amount:  24546121 total is: 31250000
Slave processor 28 total spend time:: 0.796671 s 

Slave processor 24  in_circle amount:  24544415 total is: 31250000
Slave processor 24 total spend time:: 0.797561 s 

Slave processor 25  in_circle amount:  24544792 total is: 31250000
Slave processor 25 total spend time:: 0.798117 s 

Slave processor 26  in_circle amount:  24543987 total is: 31250000
Slave processor 26 total spend time:: 0.798644 s 

Slave processor 30  in_circle amount:  24545769 total is: 31250000
Slave processor 30 total spend time:: 0.799417 s 

Slave processor 27  in_circle amount:  24544347 total is: 31250000
Slave processor 27 total spend time:: 0.799979 s 

Slave processor 29  in_circle amount:  24542815 total is: 31250000
Slave processor 29 total spend time:: 0.800532 s 

Slave processor 22  in_circle amount:  24543555 total is: 31250000
Slave processor 22 total spend time:: 0.801274 s 

Master processor 0: in_circle amount 24546655; total is 31250000
Master processor 0 work time spend time: 0.789581 s 
----------------------------
Master total time:  1.02968 s 
Communication time: 0.240099s
The 785401923 of 1000000000 points falls into the circle 

***** PI is 3.14160769
#############################################
Slave processor 31  in_circle amount:  24544323 total is: 31250000
Slave processor 31 total spend time:: 1.02922 s 

```