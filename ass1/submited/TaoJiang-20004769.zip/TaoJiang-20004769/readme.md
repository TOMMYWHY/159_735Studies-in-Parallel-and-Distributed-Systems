```shell script
mpicc first.c -o first
mpirun -n 4 first
emacs first.pbs &
qsub first.pbs
```

mac env

```shell script
mmpic++ ass_1.cpp - out
mpirun -n 4 out
```
****

