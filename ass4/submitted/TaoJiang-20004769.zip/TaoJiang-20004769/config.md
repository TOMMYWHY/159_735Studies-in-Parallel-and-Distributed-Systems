

export CUDA_HOME="/usr/local/cuda-10.0"
export LD_LIBRARY_PATH="${LD_LIBRARY_PATH}:${CUDA_HOME}/lib64"
export PATH=${CUDA_HOME}/bin:${PATH}


